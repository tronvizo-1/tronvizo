import React, { useState, useEffect } from "react";
import { motion, AnimatePresence } from "motion/react";
import { 
  Menu, 
  X, 
  ArrowRight, 
  Download, 
  Sparkles, 
  Globe2, 
  ShieldAlert, 
  Smartphone, 
  ShieldAlert as Heart, 
  ChevronRight, 
  Terminal,
  Activity,
  Cpu
} from "lucide-react";

import Logo from "./components/Logo";
import Features from "./components/Features";
import Screenshots from "./components/Screenshots";
import DownloadSection from "./components/DownloadSection";

export default function App() {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);

  // Monitor screen scroll to add glass opacity in Header navbar
  useEffect(() => {
    const handleScroll = () => {
      if (window.scrollY > 30) {
        setScrolled(true);
      } else {
        setScrolled(false);
      }
    };
    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  const navLinks = [
    { name: "Features", href: "#features" },
    { name: "Screenshots", href: "#screenshots" },
    { name: "Download APK", href: "#download-apk-hub" },
  ];

  const scrollToSection = (id: string) => {
    setMobileMenuOpen(false);
    const element = document.querySelector(id);
    if (element) {
      element.scrollIntoView({ behavior: "smooth", block: "start" });
    }
  };

  return (
    <div id="tronvizo-app-container" className="min-h-screen bg-[#030014] text-slate-100 flex flex-col relative overflow-x-hidden selection:bg-neon-blue selection:text-slate-950">
      
      {/* Absolute Ambient Colored Background Lights */}
      <div className="absolute top-0 left-[-5%] w-[500px] h-[500px] bg-purple-600/15 rounded-full blur-[120px] pointer-events-none -z-10" />
      <div className="absolute bottom-[-10%] right-[-5%] w-[600px] h-[600px] bg-blue-600/10 rounded-full blur-[150px] pointer-events-none -z-10" />
      <div className="absolute top-1/4 right-1/4 w-[500px] h-[500px] bg-neon-purple/8 rounded-full blur-[140px] pointer-events-none -z-10" />

      {/* Persistence Floating Header */}
      <header
        id="navbar-header"
        className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 px-4 md:px-8 py-4 ${
          scrolled 
            ? "bg-[#030014]/85 backdrop-blur-md border-b border-white/[0.04] shadow-lg shadow-black/10" 
            : "bg-transparent"
        }`}
      >
        <div id="navbar-container" className="max-w-6xl mx-auto flex items-center justify-between">
          
          {/* Logo with interactive text */}
          <Logo withText={true} />

          {/* Desktop Navigation Links */}
          <nav className="hidden md:flex items-center gap-8">
            {navLinks.map((link) => (
              <button
                key={link.name}
                onClick={() => scrollToSection(link.href)}
                className="text-sm font-semibold tracking-wide text-slate-300 hover:text-neon-blue transition-colors cursor-pointer"
              >
                {link.name}
              </button>
            ))}
          </nav>

          {/* Header Action APK CTA button */}
          <div className="hidden md:flex items-center gap-4">
            <button
              onClick={() => scrollToSection("#download-apk-hub")}
              className="px-5 py-2 rounded-xl bg-slate-900 hover:bg-slate-800 text-slate-100 hover:text-white transition-all text-xs font-mono font-bold tracking-wider uppercase border border-slate-800/80 hover:border-slate-600 flex items-center gap-1.5 cursor-pointer hover:shadow-[0_0_12px_rgba(0,240,255,0.2)]"
            >
              <Download className="w-3.5 h-3.5 text-neon-blue" />
              <span>Free APK</span>
            </button>
          </div>

          {/* Mobile Hamburg menu button */}
          <button
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            className="p-2 md:hidden text-slate-300 hover:text-white transition-colors"
          >
            {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
          </button>
        </div>
      </header>

      {/* Mobile Menu Backdrop & Panel */}
      <AnimatePresence>
        {mobileMenuOpen && (
          <motion.div
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            transition={{ duration: 0.2 }}
            className="fixed inset-0 top-[64px] z-40 bg-[#030014]/95 backdrop-blur-lg flex flex-col p-6 space-y-6 border-b border-slate-900 md:hidden"
          >
            <div className="flex flex-col space-y-4">
              {navLinks.map((link) => (
                <button
                  key={link.name}
                  onClick={() => scrollToSection(link.href)}
                  className="text-left text-lg font-semibold tracking-wide py-1 text-slate-300 hover:text-neon-blue transition-colors cursor-pointer"
                >
                  {link.name}
                </button>
              ))}
            </div>

            <div className="border-t border-slate-900 pt-6 flex flex-col gap-4">
              <button
                onClick={() => scrollToSection("#download-apk-hub")}
                className="w-full py-3.5 rounded-xl bg-gradient-to-r from-neon-blue to-neon-purple text-slate-950 font-display font-bold text-sm tracking-widest uppercase flex items-center justify-center gap-2 cursor-pointer shadow-lg shadow-neon-blue/20"
              >
                <Download className="w-4 h-4 fill-current" />
                <span>Download TRONVIZO APK</span>
              </button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Main Page Layout Wrapper */}
      <main id="main-content-layout" className="flex-grow pt-24">
        
        {/* SECTION 1: HERO CONTAINER SECTION */}
        <section id="hero-area" className="py-16 md:py-24 px-4 md:px-8 relative">
          
          <div className="max-w-6xl mx-auto grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
            
            {/* Left Column: Descriptive Text content */}
            <div className="lg:col-span-12 text-center max-w-4xl mx-auto space-y-6">
              
              {/* Futuristic floating brand chip */}
              <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-slate-950/80 border border-slate-800/80 text-xs font-mono font-bold uppercase tracking-widest text-slate-300 mb-2">
                <Globe2 className="w-3.5 h-3.5 text-neon-blue animate-spin-slow" style={{ animationDuration: "15s" }} />
                <span>Next-Gen Voice translation</span>
                <span className="text-neon-purple">● offline first</span>
              </div>

              {/* High impact display tagline */}
              <h1 className="text-4xl sm:text-6xl md:text-7xl font-display font-black tracking-tight text-white leading-none">
                Converse Fluidly <br />
                <span className="text-transparent bg-clip-text bg-gradient-to-r from-neon-blue via-violet-500 to-neon-pink">
                  In Any Language.
                </span>
              </h1>

              {/* Core App Description */}
              <p className="text-base sm:text-lg md:text-xl text-slate-400 font-light leading-relaxed max-w-2xl mx-auto">
                TRONVIZO is a real-time AI voice translator app for travelers. Speak in your native tongue and instantly hear natural, vocally synthesized translations back in another language.
              </p>

              {/* Hero Call To Actions */}
              <div className="flex flex-col sm:flex-row justify-center items-center gap-4 pt-4">
                <button
                  onClick={() => scrollToSection("#download-apk-hub")}
                  className="w-full sm:w-auto px-8 py-4 rounded-xl bg-gradient-to-r from-neon-blue to-neon-purple text-slate-950 font-display font-bold text-sm tracking-widest hover:scale-[1.03] transition-all cursor-pointer shadow-[0_0_24px_rgba(0,240,255,0.3)] flex items-center justify-center gap-2 uppercase select-none"
                >
                  <Download className="w-4 h-4 stroke-[2.5px]" />
                  <span>Download APK</span>
                </button>
              </div>

              {/* Spec list quick tags */}
              <div className="flex flex-wrap items-center justify-center gap-x-6 gap-y-2 pt-6 text-[11px] font-mono tracking-wider text-slate-500 uppercase">
                <span className="flex items-center gap-1"><Activity className="w-3.5 h-3.5 text-neon-blue" /> SUB-200MS LATENCY</span>
                <span className="hidden sm:inline">|</span>
                <span className="flex items-center gap-1"><Cpu className="w-3.5 h-3.5 text-neon-purple" /> SMART IDIOM AI</span>
                <span className="hidden sm:inline">|</span>
                <span className="flex items-center gap-1"><TermSymbol /> NO ADS / SIGNUPS</span>
              </div>
            </div>

          </div>
        </section>

        {/* SECTION 3: FEATURES GRID (Bento grid representation) */}
        <Features />

        {/* SECTION 4: SMART INTERFACE SCREENSHOTS */}
        <Screenshots />

        {/* SECTION 5: DOWNLOAD STANDALONE APK */}
        <DownloadSection />

      </main>

      {/* SECTION 6: THEME EMBODYING FOOTER */}
      <footer id="main-footer" className="bg-slate-950/80 border-t border-slate-900 pt-16 pb-12 px-4 md:px-8 relative overflow-hidden">
        
        {/* Subtle bottom gradient sweep */}
        <div className="absolute bottom-0 left-0 right-0 h-[2px] bg-gradient-to-r from-neon-blue via-neon-purple to-neon-pink" />

        <div className="max-w-6xl mx-auto">
          <div className="grid grid-cols-1 md:grid-cols-12 gap-8 mb-12">
            
            {/* Col 1: Branding */}
            <div className="md:col-span-5 space-y-4">
              <Logo withText={true} />
              <p className="text-xs text-slate-400 leading-relaxed font-light max-w-sm">
                TRONVIZO represents the future of real-time voice translation logic. Engineered specifically for global adventurers, backpackers, and travelers. Reconnecting humanity, one sentence at a time.
              </p>
              
              <div className="inline-flex items-center gap-1.5 text-xs text-slate-500 font-mono mt-1">
                <span>Designed for</span>
                <span className="text-slate-300 font-semibold px-2 py-0.5 bg-slate-900 rounded border border-slate-800">Travel & Leisure</span>
              </div>
            </div>

            {/* Col 2: Navigation references */}
            <div className="md:col-span-3 space-y-3">
              <h4 className="text-xs font-mono font-bold uppercase tracking-widest text-[#BD00FF]">Quick Navigation</h4>
              <ul className="space-y-2 text-xs">
                <li>
                  <button onClick={() => scrollToSection("#features")} className="text-slate-400 hover:text-white transition-colors cursor-pointer">
                    App Features
                  </button>
                </li>
                <li>
                  <button onClick={() => scrollToSection("#screenshots")} className="text-slate-400 hover:text-white transition-colors cursor-pointer">
                    Software Interfaces
                  </button>
                </li>
                <li>
                  <button onClick={() => scrollToSection("#download-apk-hub")} className="text-slate-400 hover:text-white transition-colors cursor-pointer">
                    Download APK Releases
                  </button>
                </li>
              </ul>
            </div>

            {/* Col 3: Specifications and compatibility logs */}
            <div className="md:col-span-4 space-y-3">
              <h4 className="text-xs font-mono font-bold uppercase tracking-widest text-neon-blue">Aesthetic Details</h4>
              <ul className="space-y-2 text-slate-400 text-xs font-mono">
                <li>COMPATIBILITY: Android Oreo 8.0+</li>
                <li>SYSTEM MODULE: Speech Synthesis (TTS)</li>
                <li>LANGUAGE INDEXES: 104 Global Dialects</li>
                <li>AI ARCHITECTURE: Gemini Context Aware</li>
                <li>DEVELOPMENT BUILD: React v19 + Tailwind v4</li>
              </ul>
            </div>

          </div>

          {/* Copyright line */}
          <div className="border-t border-slate-900 pt-8 flex flex-col sm:flex-row items-center justify-between gap-4 text-[11px] text-slate-500 font-mono">
            <span>© {new Date().getFullYear()} TRONVIZO AI TRANS. ALL RIGHTS RESERVED.</span>
            <div className="flex gap-4">
              <a href="#" className="hover:text-slate-300 transition-all">PRIVACY CONTRACT</a>
              <span>•</span>
              <a href="#" className="hover:text-slate-300 transition-all">USER LICENSE AGREEMENT</a>
            </div>
          </div>

        </div>
      </footer>

    </div>
  );
}

// Help sub-icons
function TermSymbol() {
  return (
    <span className="inline-flex items-center gap-1 text-slate-500 font-bold font-mono">
      <Terminal className="w-3.5 h-3.5 text-neon-pink" />
    </span>
  );
}
