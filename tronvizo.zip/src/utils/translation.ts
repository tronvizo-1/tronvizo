import { Language, TranslationPreset } from "../types";

export const LANGUAGES: Language[] = [
  { code: "en", name: "English (US)", flag: "🇺🇸", locale: "en-US", placeholder: "Say or type something..." },
  { code: "es", name: "Spanish", flag: "🇪🇸", locale: "es-ES", placeholder: "Diga o escriba algo..." },
  { code: "ja", name: "Japanese", flag: "🇯🇵", locale: "ja-JP", placeholder: "話すか、入力してください..." },
  { code: "hi", name: "Hindi", flag: "🇮🇳", locale: "hi-IN", placeholder: "बोलें या कुछ लिखें..." },
  { code: "fr", name: "French", flag: "🇫🇷", locale: "fr-FR", placeholder: "Dites ou tapez quelque chose..." },
  { code: "de", name: "German", flag: "🇩🇪", locale: "de-DE", placeholder: "Sprechen oder tippen Sie..." },
  { code: "it", name: "Italian", flag: "🇮🇹", locale: "it-IT", placeholder: "Dica o digiti qualcosa..." },
  { code: "zh", name: "Chinese (Simplified)", flag: "🇨🇳", locale: "zh-CN", placeholder: "请说话或输入..." },
];

export const TRANSLATION_PRESETS: TranslationPreset[] = [
  {
    source: "Where is the train station?",
    target: "es",
    text: "Where is the train station?",
    translation: "¿Dónde está la estación de tren?"
  },
  {
    source: "Where is the train station?",
    target: "ja",
    text: "Where is the train station?",
    translation: "駅はどこですか？ (Eki wa doko desu ka?)"
  },
  {
    source: "Where is the train station?",
    target: "hi",
    text: "Where is the train station?",
    translation: "ट्रेन स्टेशन कहाँ है?"
  },
  {
    source: "Where is the train station?",
    target: "fr",
    text: "Where is the train station?",
    translation: "Où se trouve la gare ?"
  },
  {
    source: "Where is the train station?",
    target: "de",
    text: "Where is the train station?",
    translation: "Wo ist der Bahnhof?"
  },
  {
    source: "How much does this cost?",
    target: "es",
    text: "How much does this cost?",
    translation: "¿Cuánto cuesta esto?"
  },
  {
    source: "How much does this cost?",
    target: "ja",
    text: "How much does this cost?",
    translation: "これはいくらですか？ (Kore wa ikura desu ka?)"
  },
  {
    source: "How much does this cost?",
    target: "hi",
    text: "How much does this cost?",
    translation: "यह कितने का है?"
  },
  {
    source: "How much does this cost?",
    target: "fr",
    text: "How much does this cost?",
    translation: "Combien ça coûte ?"
  },
  {
    source: "Can you help me, please?",
    target: "es",
    text: "Can you help me, please?",
    translation: "¿Me puede ayudar, por favor?"
  },
  {
    source: "Can you help me, please?",
    target: "ja",
    text: "Can you help me, please?",
    translation: "助けていただけますか？ (Tasukete itadakemasu ka?)"
  },
  {
    source: "Can you help me, please?",
    target: "hi",
    text: "Can you help me, please?",
    translation: "क्या आप मेरी मदद कर सकते हैं, कृपया?"
  },
  {
    source: "Can you help me, please?",
    target: "fr",
    text: "Can you help me, please?",
    translation: "Pouvez-vous m'aider, s'il vous plaît ?"
  },
  {
    source: "Hello! Nice to meet you.",
    target: "es",
    text: "Hello! Nice to meet you.",
    translation: "¡Hola! Encantado de conocerte."
  },
  {
    source: "Hello! Nice to meet you.",
    target: "ja",
    text: "Hello! Nice to meet you.",
    translation: "こんにちは！はじめまして。 (Konnichiwa! Hajimemashite.)"
  },
  {
    source: "Hello! Nice to meet you.",
    target: "hi",
    text: "Hello! Nice to meet you.",
    translation: "नमस्ते! आपसे मिलकर बहुत अच्छा लगा।"
  },
  {
    source: "Hello! Nice to meet you.",
    target: "fr",
    text: "Hello! Nice to meet you.",
    translation: "Bonjour ! Ravi de vous rencontrer."
  },
  {
    source: "Where is the nearest restaurant?",
    target: "es",
    text: "Where is the nearest restaurant?",
    translation: "¿Dónde está el restaurante más cercano?"
  },
  {
    source: "Where is the nearest restaurant?",
    target: "ja",
    text: "Where is the nearest restaurant?",
    translation: "一番近いレストランはどこですか？ (Ichiban chikai resutoran wa doko desu ka?)"
  },
  {
    source: "Where is the nearest restaurant?",
    target: "hi",
    text: "Where is the nearest restaurant?",
    translation: "सबसे पास का रेस्टोरेंट कहाँ है?"
  },
  {
    source: "Where is the nearest restaurant?",
    target: "fr",
    text: "Where is the nearest restaurant?",
    translation: "Où se trouve le restaurant le plus proche ?"
  }
];

// Fallback dictionary for arbitrary text translation simulation
export function getSmartMockTranslation(text: string, targetLangCode: string): string {
  const norm = text.toLowerCase().trim().replace(/[?.!,]/g, "");
  
  // Find predefined exact match
  const exact = TRANSLATION_PRESETS.find(
    p => p.source.toLowerCase().replace(/[?.!,]/g, "") === norm && p.target === targetLangCode
  );
  if (exact) return exact.translation;

  // Dictionary decomposition
  const mappings: Record<string, Record<string, string>> = {
    es: {
      "hello": "Hola",
      "thank you": "Gracias",
      "good morning": "Buenos días",
      "good night": "Buenas noches",
      "water": "agua",
      "food": "comida",
      "hotel": "hotel",
      "airport": "aeropuerto",
      "taxi": "taxi",
      "where is": "¿Dónde está",
      "taxi please": "un taxi, por favor",
      "excuse me": "Disculpe",
      "friend": "amigo",
      "yes": "Sí",
      "no": "No",
      "please": "por favor",
      "beautiful": "hermoso",
      "travel": "viajar"
    },
    ja: {
      "hello": "こんにちは (Konnichiwa)",
      "thank you": "ありがとう (Arigatou)",
      "good morning": "おはようございます (Ohayou gozaimasu)",
      "good night": "おやすみなさい (Oyasuminasai)",
      "water": "水 (Mizu)",
      "food": "食べ物 (Tabemono)",
      "hotel": "ホテル (Hoteru)",
      "airport": "空港 (Kuukou)",
      "taxi": "タクシー (Takushii)",
      "where is": "はどこですか (..wa doko desu ka?)",
      "excuse me": "すみません (Sumimasen)",
      "friend": "友達 (Tomodachi)",
      "yes": "はい (Hai)",
      "no": "いいえ (Iie)",
      "please": "お願いします (Onegai shimasu)",
      "beautiful": "美しい (Utsukushii)",
      "travel": "旅行 (Ryokou)"
    },
    hi: {
      "hello": "नमस्ते (Namaste)",
      "thank you": "धन्यवाद (Dhanyavaad)",
      "good morning": "शुभ प्रभात (Shubh Prabhaat)",
      "good night": "शुभ रात्रि (Shubh Raatri)",
      "water": "पानी (Paani)",
      "food": "खाना (Khaana)",
      "hotel": "होटल (Hotel)",
      "airport": "हवाई अड्डा (Hawai Adda)",
      "taxi": "टैक्सी (Taxi)",
      "where is": "कहाँ है? (Kahan hai?)",
      "excuse me": "माफ़ कीजिये (Maaf kijiye)",
      "friend": "दोस्त (Dost)",
      "yes": "हाँ (Haan)",
      "no": "नहीं (Nahi)",
      "please": "कृपया (Kripya)",
      "beautiful": "सुंदर (Sundar)",
      "travel": "यात्रा (Yaatra)"
    },
    fr: {
      "hello": "Bonjour",
      "thank you": "Merci",
      "good morning": "Bon matin",
      "good night": "Bonne nuit",
      "water": "de l'eau",
      "food": "nourriture",
      "hotel": "hôtel",
      "airport": "aéroport",
      "taxi": "taxi",
      "where is": "Où est",
      "excuse me": "Excusez-moi",
      "friend": "ami",
      "yes": "Oui",
      "no": "Non",
      "please": "s'il vous plaît",
      "beautiful": "magnifique",
      "travel": "voyager"
    },
    de: {
      "hello": "Hallo",
      "thank you": "Danke",
      "good morning": "Guten Morgen",
      "good night": "Gute Nacht",
      "water": "Wasser",
      "food": "Essen",
      "hotel": "Hotel",
      "airport": "Flughafen",
      "taxi": "Taxi",
      "where is": "Wo ist",
      "excuse me": "Entschuldigung",
      "friend": "Freund",
      "yes": "Ja",
      "no": "Nein",
      "please": "bitte",
      "beautiful": "wunderschön",
      "travel": "reisen"
    },
    it: {
      "hello": "Ciao",
      "thank you": "Grazie",
      "good morning": "Buongiorno",
      "good night": "Buonanotte",
      "water": "acqua",
      "food": "cibo",
      "hotel": "hotel",
      "airport": "aeroporto",
      "taxi": "taxi",
      "where is": "Dove si trova",
      "excuse me": "Scusi",
      "friend": "amico",
      "yes": "Sì",
      "no": "No",
      "please": "per favore",
      "beautiful": "bellissimo",
      "travel": "viaggio"
    },
    zh: {
      "hello": "你好 (Nǐ hǎo)",
      "thank you": "谢谢 (Xièxiè)",
      "good morning": "早上好 (Zǎoshang hǎo)",
      "good night": "晚安 (Wǎn'ān)",
      "water": "水 (Shuǐ)",
      "food": "食物 (Shíwù)",
      "hotel": "酒店 (Jiǔdiàn)",
      "airport": "机场 (Jīchǎng)",
      "taxi": "出租车 (Chūzū chē)",
      "where is": "在哪里 (Zài nǎlǐ)",
      "excuse me": "打扰一下 (Dǎrǎo yīxià)",
      "friend": "朋友 (Péngyǒu)",
      "yes": "ใช่ (Shì / 对)",
      "no": "不 (Bù)",
      "please": "请 (Qǐng)",
      "beautiful": "美丽 (Měilì)",
      "travel": "旅行 (Lǚxíng)"
    }
  };

  const langMap = mappings[targetLangCode];
  if (!langMap) {
    return `[Translated to ${targetLangCode.toUpperCase()}]: ${text}`;
  }

  // Attempt word by word translation translation for mockup
  let matches = false;
  let translatedText = text;

  // Simple key substitution
  for (const [enKey, targetVal] of Object.entries(langMap)) {
    const rx = new RegExp(`\\b${enKey}\\b`, "gi");
    if (rx.test(translatedText)) {
      translatedText = translatedText.replace(rx, targetVal);
      matches = true;
    }
  }

  if (matches) {
    return translatedText;
  }

  // Generic travel-oriented conversion
  const genericTrans: Record<string, string> = {
    es: "¡Traducido al instante por TRONVIZO AI! ⚡",
    ja: "TRONVIZO AIで瞬時に翻訳されました！ ✨",
    hi: "TRONVIZO AI द्वारा तुरंत अनुवादित! 🚀",
    fr: "Traduit instantanément par TRONVIZO AI ! ⚡",
    de: "Sofort übersetzt von TRONVIZO AI! 🛡️",
    it: "Tradotto all'istante da TRONVIZO AI! 🍀",
    zh: "由 TRONVIZO AI 瞬间翻译！ 💎"
  };

  return `${text} — ${genericTrans[targetLangCode] || "Translated by TRONVIZO"}`;
}
