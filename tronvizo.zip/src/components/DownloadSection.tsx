import React, { useState } from "react";
import { motion, AnimatePresence } from "motion/react";
import { Download, ShieldCheck, Heart, ArrowRight, Smartphone, RefreshCw, Check, Sparkles } from "lucide-react";

export default function DownloadSection() {
  const [downloadState, setDownloadState] = useState<"idle" | "loading" | "complete">("idle");
  const [downloadProgress, setDownloadProgress] = useState(0);

  const startDownload = () => {
    if (downloadState !== "idle") return;
    setDownloadState("loading");
    setDownloadProgress(0);

    const interval = setInterval(() => {
      setDownloadProgress((prev) => {
        if (prev >= 100) {
          clearInterval(interval);
          setDownloadState("complete");
          return 100;
        }
        return prev + Math.floor(Math.random() * 15) + 5;
      });
    }, 180);
  };

  const resetDownload = () => {
    setDownloadState("idle");
    setDownloadProgress(0);
  };

  return (
    <section id="download-apk-hub" className="py-24 px-4 md:px-8 relative">
      {/* Decorative ambient neon background rings */}
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-96 h-96 bg-neon-blue/10 rounded-full blur-3xl pointer-events-none -z-10" />

      <div className="max-w-4xl mx-auto">
        
        {/* Rounded Glassmorphic Hub Wrapper */}
        <div className="glass-morphic rounded-3xl p-8 md:p-12 border border-neon-purple/20 relative overflow-hidden neon-border-glow text-center">
          
          <div className="absolute top-0 right-0 w-32 h-32 bg-neon-purple/10 rounded-full blur-2xl pointer-events-none" />
          <div className="absolute bottom-0 left-0 w-32 h-32 bg-neon-blue/10 rounded-full blur-2xl pointer-events-none" />

          {/* Section Headers */}
          <div className="max-w-xl mx-auto space-y-4 mb-10">
            <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-slate-900 border border-slate-800 text-[10px] font-mono font-semibold tracking-wider text-neon-blue uppercase">
              <Smartphone className="w-3.5 h-3.5" />
              <span>Android Deployment Package</span>
            </div>
            
            <h2 className="text-3xl md:text-5xl font-display font-black text-white tracking-tight leading-tight">
              Get TRONVIZO Now
            </h2>
            
            <p className="text-xs md:text-sm text-slate-400 font-light leading-relaxed">
              Experience dynamic translation speeds with our standalone APK release. Fully optimized for instant travel execution and speech-to-speech feedback.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8 items-center max-w-3xl mx-auto">
            
            {/* Download Action Column */}
            <div className="flex flex-col items-center justify-center space-y-4">
              
              <AnimatePresence mode="wait">
                {downloadState === "idle" && (
                  <motion.div
                    key="idle"
                    initial={{ opacity: 0, scale: 0.95 }}
                    animate={{ opacity: 1, scale: 1 }}
                    exit={{ opacity: 0, scale: 0.95 }}
                    className="w-full text-center space-y-4"
                  >
                    <button
                      onClick={startDownload}
                      className="w-full max-w-xs py-4 px-6 rounded-2xl bg-gradient-to-r from-neon-blue via-violet-600 to-neon-purple text-slate-950 font-display font-bold text-sm tracking-widest hover:scale-[1.03] transition-all cursor-pointer shadow-[0_0_24px_rgba(0,240,255,0.4)] flex items-center justify-center gap-3 uppercase select-none"
                    >
                      <Download className="w-5 h-5 stroke-[2.5px]" />
                      <span>Download TRONVIZO APK</span>
                    </button>
                    <p className="text-[10px] font-mono text-slate-500 uppercase tracking-wider">
                      DIRECT ENCRYPTED SECURE APK DOWNLOAD
                    </p>
                  </motion.div>
                )}

                {downloadState === "loading" && (
                  <motion.div
                    key="loading"
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, y: -10 }}
                    className="w-full max-w-xs space-y-3 bg-slate-950 p-6 rounded-2xl border border-slate-800"
                  >
                    <div className="flex justify-between items-center text-xs font-mono">
                      <span className="text-neon-blue animate-pulse">Downloading APK...</span>
                      <span className="text-slate-300 font-bold">{downloadProgress}%</span>
                    </div>
                    {/* Progress bar container */}
                    <div className="w-full h-2 rounded-full bg-slate-900 overflow-hidden">
                      <motion.div 
                        className="h-full bg-gradient-to-r from-neon-blue to-neon-purple rounded-full"
                        style={{ width: `${downloadProgress}%` }}
                      />
                    </div>
                    <div className="text-[10px] font-mono text-slate-500">
                      Linking server clusters / securing checksums...
                    </div>
                  </motion.div>
                )}

                {downloadState === "complete" && (
                  <motion.div
                    key="complete"
                    initial={{ opacity: 0, scale: 0.95 }}
                    animate={{ opacity: 1, scale: 1 }}
                    exit={{ opacity: 0, scale: 0.95 }}
                    className="w-full max-w-xs space-y-4 bg-slate-950/80 p-6 rounded-2xl border border-emerald-500/30 flex flex-col items-center"
                  >
                    <div className="w-12 h-12 rounded-full bg-emerald-500/10 border border-emerald-500/40 flex items-center justify-center text-emerald-400">
                      <Check className="w-6 h-6 stroke-[3px]" />
                    </div>
                    <div className="text-center">
                      <h4 className="text-sm font-semibold text-white">APK Download Complete!</h4>
                      <p className="text-[10px] text-slate-400 mt-1 leading-normal">
                        Ready to install on your Android phone. Follow local prompts to run TRONVIZO.
                      </p>
                    </div>
                    <button
                      onClick={resetDownload}
                      className="px-3 py-1.5 rounded-lg bg-slate-900 hover:bg-slate-800 text-slate-400 hover:text-slate-200 transition-colors font-mono text-[10px] flex items-center gap-1 cursor-pointer border border-slate-800"
                    >
                      <RefreshCw className="w-3 h-3" />
                      <span>Download again</span>
                    </button>
                  </motion.div>
                )}
              </AnimatePresence>

              {/* Verified security certifications */}
              <div className="inline-flex items-center gap-2 text-xs font-medium text-slate-400">
                <ShieldCheck className="w-4 h-4 text-emerald-500" />
                <span>Verified Play Protect Safe</span>
                <span className="text-slate-600">|</span>
                <span className="text-[11px] font-mono text-slate-500">Version 2.4.1</span>
              </div>
            </div>

            {/* QR Scanner Mock Column */}
            <div className="flex flex-col items-center bg-slate-950/60 p-6 rounded-2xl border border-slate-900 max-w-xs mx-auto">
              <div className="p-3 bg-white rounded-xl mb-3.5 relative overflow-hidden group">
                {/* SVG mock QR Code */}
                <svg viewBox="0 0 100 100" className="w-28 h-28" fill="none">
                  {/* Outer board bounds */}
                  <rect width="100" height="100" rx="4" fill="#ffffff" />
                  {/* Top-left corner box anchor */}
                  <rect x="8" y="8" width="22" height="22" stroke="#000000" strokeWidth="4" fill="none" />
                  <rect x="14" y="14" width="10" height="10" fill="#000000" />
                  {/* Top-right corner box anchor */}
                  <rect x="70" y="8" width="22" height="22" stroke="#000000" strokeWidth="4" fill="none" />
                  <rect x="76" y="14" width="10" height="10" fill="#000000" />
                  {/* Bottom-left corner box anchor */}
                  <rect x="8" y="70" width="22" height="22" stroke="#000000" strokeWidth="4" fill="none" />
                  <rect x="14" y="76" width="10" height="10" fill="#000000" />
                  
                  {/* Random qr dots matrix elements */}
                  <rect x="36" y="8" width="8" height="8" fill="#1e1e24" />
                  <rect x="52" y="12" width="6" height="6" fill="#0c0c1e" />
                  <rect x="62" y="24" width="6" height="6" fill="#1e1e24" />
                  <rect x="36" y="24" width="12" height="6" fill="#0c0c1e" />
                  <rect x="10" y="44" width="6" height="12" fill="#0c0c1e" />
                  <rect x="22" y="44" width="10" height="6" fill="#1e1e24" />
                  <rect x="26" y="56" width="14" height="6" fill="#2d0b5a" />
                  <rect x="44" y="44" width="14" height="14" fill="#0c0c1e" />
                  <rect x="62" y="44" width="10" height="6" fill="#1e1e24" />
                  <rect x="82" y="44" width="10" height="10" fill="#0d0d2b" />
                  <rect x="82" y="60" width="10" height="8" fill="#1e1e24" />
                  <rect x="44" y="68" width="10" height="14" fill="#120c32" />
                  <rect x="60" y="68" width="6" height="10" fill="#0c0c1e" />
                  <rect x="74" y="72" width="14" height="6" fill="#0c0c1e" />
                  <rect x="74" y="86" width="6" height="6" fill="#1e1e24" />
                  <rect x="88" y="82" width="6" height="10" fill="#2d0b5a" />
                  <rect x="88" y="94" width="24" height="4" fill="#000000" />
                  
                  {/* Subtle decorative target center */}
                  <rect x="45" y="45" width="10" height="10" fill="#bd00ff" opacity="0.8" />
                </svg>
              </div>
              <p className="text-[10px] font-mono font-bold text-slate-300 uppercase tracking-widest text-center mt-2">
                Scan QR to install on phone
              </p>
              <span className="text-[9px] text-slate-500 mt-1">Supports Android 8.0+ and newer models</span>
            </div>

          </div>

          {/* Release Specifications footer details within the card panel */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mt-12 pt-8 border-t border-slate-900 max-w-3xl mx-auto">
            <div className="text-left md:text-center">
              <span className="text-[10px] text-slate-500 font-mono block uppercase">File Name</span>
              <span className="text-xs font-semibold text-slate-300 font-mono mt-0.5 block">tronvizo-v2.4.1.apk</span>
            </div>
            <div className="text-left md:text-center">
              <span className="text-[10px] text-slate-500 font-mono block uppercase">File Size</span>
              <span className="text-xs font-semibold text-slate-300 font-mono mt-0.5 block">18.47 Megabytes</span>
            </div>
            <div className="text-left md:text-center">
              <span className="text-[10px] text-slate-500 font-mono block uppercase">SHA-256 Checksum</span>
              <span className="text-xs font-semibold text-slate-300 font-mono mt-0.5 block truncate max-w-[130px] mx-auto" title="4c96ddbf6e2e5ffce63cdd7b">4c96ddbf6e2e5ffce63cdd7b</span>
            </div>
            <div className="text-left md:text-center">
              <span className="text-[10px] text-slate-500 font-mono block uppercase">Ad Policy</span>
              <span className="text-xs font-semibold text-emerald-400 font-mono mt-0.5 block">100% Ad-Free</span>
            </div>
          </div>

        </div>

      </div>
    </section>
  );
}
