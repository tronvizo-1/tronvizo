import React from "react";
import { motion } from "motion/react";

interface LogoProps {
  className?: string; // For scaling
  withText?: boolean;
  pulse?: boolean;
}

export default function Logo({ className = "w-12 h-12", withText = false, pulse = false }: LogoProps) {
  return (
    <div className="flex items-center gap-3 select-none">
      <motion.div
        className={`relative ${className}`}
        animate={pulse ? { scale: [1, 1.08, 1] } : undefined}
        transition={{ duration: 2, repeat: Infinity, ease: "easeInOut" }}
        whileHover={{ scale: 1.1, rotate: -20 }}
      >
        <svg
          viewBox="0 0 200 200"
          className="w-full h-full drop-shadow-[0_0_12px_rgba(189,0,255,0.4)]"
          fill="none"
          xmlns="http://www.w3.org/2000/svg"
        >
          <defs>
            {/* Top-Right Arrow Gradient (Orange-Red) */}
            <linearGradient id="orangeRedGrad" x1="160" y1="30" x2="60" y2="130" gradientUnits="userSpaceOnUse">
              <stop offset="0%" stopColor="#FF8F00" />
              <stop offset="50%" stopColor="#FF3D00" />
              <stop offset="100%" stopColor="#E0115F" />
            </linearGradient>

            {/* Bottom-Left Arrow Gradient (Blue-Purple) */}
            <linearGradient id="bluePurpleGrad" x1="40" y1="170" x2="140" y2="70" gradientUnits="userSpaceOnUse">
              <stop offset="0%" stopColor="#00F0FF" />
              <stop offset="50%" stopColor="#005BFF" />
              <stop offset="100%" stopColor="#BD00FF" />
            </linearGradient>

            {/* Inner Accents Gradient */}
            <linearGradient id="magentaGrad" x1="100" y1="50" x2="100" y2="150" gradientUnits="userSpaceOnUse">
              <stop offset="0%" stopColor="#FF007F" />
              <stop offset="100%" stopColor="#8A00FF" />
            </linearGradient>
          </defs>

          {/* Top-Right Orange-Red Arrow */}
          <path
            d="M 125 35 
               C 165 50, 185 90, 175 130
               C 170 150, 155 165, 135 172
               C 134 162, 137 150, 142 140
               C 152 115, 145 92, 125 75
               C 112 64, 95 60, 80 62
               L 80 82
               L 30 42
               L 80 2
               L 80 22
               C 95 21, 110 25, 125 35 Z"
            fill="url(#orangeRedGrad)"
          />

          {/* Bottom-Left Blue-Purple Arrow */}
          <path
            d="M 75 165
               C 35 150, 15 110, 25 70
               C 30 50, 45 35, 65 28
               C 66 38, 63 50, 58 60
               C 48 85, 55 108, 75 125
               C 88 136, 105 140, 120 138
               L 120 118
               L 170 158
               L 120 198
               L 120 178
               C 105 179, 90 175, 75 165 Z"
            fill="url(#bluePurpleGrad)"
          />

          {/* Inner Accent Crescents (Pink Magenta/Purple lines) */}
          <path
            d="M 75 80 
               C 70 95, 75 115, 87 122
               C 85 118, 83 110, 83 103
               C 83 94, 85 86, 90 80
               C 84 80, 79 80, 75 80 Z"
            fill="url(#magentaGrad)"
            opacity="0.95"
          />

          <path
            d="M 125 120 
               C 130 105, 125 85, 113 78
               C 115 82, 117 90, 117 97
               C 117 106, 115 114, 110 120
               C 116 120, 121 120, 125 120 Z"
            fill="url(#magentaGrad)"
            opacity="0.95"
          />
        </svg>

        {/* Small background glow ring */}
        <div className="absolute inset-0 rounded-full bg-gradient-to-tr from-neon-blue to-neon-purple opacity-20 blur-xl -z-10 animate-pulse-slow" />
      </motion.div>

      {withText && (
        <span className="font-display font-bold text-2xl tracking-wider bg-gradient-to-r from-white via-slate-100 to-neon-blue bg-clip-text text-transparent flex items-center gap-1">
          TRON<span className="text-neon-blue select-all text-shadow-[0_0_10px_rgba(0,240,255,0.6)]">VIZO</span>
        </span>
      )}
    </div>
  );
}
