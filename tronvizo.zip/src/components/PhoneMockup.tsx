import React from "react";
import { motion } from "motion/react";
import { Mic, Globe, History, Camera, Check, ShieldCheck, Heart, Sparkles, Navigation, Signal, Wifi, Battery, ChevronRight, Play } from "lucide-react";

interface PhoneMockupProps {
  type: "chat" | "camera" | "history";
  active?: boolean;
}

export default function PhoneMockup({ type, active = false }: PhoneMockupProps) {
  return (
    <motion.div
      className={`relative w-72 h-[550px] rounded-[42px] bg-slate-950 border-4 border-slate-800 p-2.5 shadow-2xl transition-all duration-500 overflow-hidden ${
        active 
          ? "border-neon-purple shadow-[0_0_35px_rgba(189,0,255,0.4)] scale-102" 
          : "border-slate-800 shadow-[0_15px_30px_rgba(0,0,0,0.4)] scale-98"
      }`}
      animate={active ? { y: [0, -6, 0] } : undefined}
      transition={{ repeat: Infinity, duration: 4, ease: "easeInOut" }}
    >
      {/* Outer Phone Ring Screen shadow */}
      <div className="absolute inset-0 bg-slate-950 rounded-[38px] overflow-hidden flex flex-col justify-between">
        
        {/* Dynamic Island / Camera slot info */}
        <div className="absolute top-2 left-1/2 -translate-x-1/2 w-28 h-5 bg-slate-900 rounded-full z-30 flex items-center justify-between px-3">
          <div className="w-1.5 h-1.5 rounded-full bg-blue-500/80" />
          <div className="w-10 h-1 bg-slate-800/80 rounded" />
          <div className="w-1.5 h-1.5 rounded-full bg-slate-950" />
        </div>

        {/* Operating System Status Bar */}
        <div className="w-full h-8 pt-2 px-6 flex items-center justify-between text-[10px] font-mono font-semibold text-slate-400 bg-slate-950/85 z-20">
          <span>09:41 AM</span>
          <div className="flex items-center gap-1.5">
            <Signal className="w-2.5 h-2.5" />
            <Wifi className="w-2.5 h-2.5" />
            <Battery className="w-3.5 h-2" />
          </div>
        </div>

        {/* Outer Background and Glowing elements specific to Mockup Screen */}
        <div className="flex-grow flex flex-col justify-between p-3.5 pt-1.5 overflow-hidden relative">
          
          {/* Subtle applet glow within screen */}
          <div className="absolute top-1/4 -left-16 w-36 h-36 bg-neon-blue/20 rounded-full blur-2xl pointer-events-none" />
          <div className="absolute bottom-1/4 -right-16 w-36 h-36 bg-neon-purple/20 rounded-full blur-2xl pointer-events-none" />

          {/* SCREEN CONTENT 1: CHAT TRANSLATOR */}
          {type === "chat" && (
            <div className="flex-grow flex flex-col justify-between h-full pt-1">
              {/* App bar inside mockup */}
              <div className="flex items-center justify-between border-b border-white/[0.04] pb-2">
                <div className="flex items-center gap-1.5">
                  <div className="w-6 h-6 rounded-full bg-gradient-to-tr from-neon-blue to-neon-purple p-0.5">
                    <div className="w-full h-full bg-slate-950 rounded-full flex items-center justify-center text-[8px]">🎯</div>
                  </div>
                  <span className="font-display font-bold text-xs tracking-wide">TRONVIZO AI</span>
                </div>
                <Globe className="w-3.5 h-3.5 text-neon-blue animate-spin-slow" style={{ animationDuration: "12s" }} />
              </div>

              {/* Chat Subtitle logs */}
              <div className="flex-grow flex flex-col gap-3 py-3 overflow-y-auto no-scrollbar justify-end">
                {/* Speaker 1 (English) */}
                <div className="flex flex-col gap-1 items-start max-w-[85%] self-start">
                  <div className="flex items-center gap-1">
                    <span className="text-[10px]">🇺🇸</span>
                    <span className="text-[8px] text-slate-400 font-mono">English</span>
                  </div>
                  <div className="bg-slate-900/90 py-2 px-3 rounded-2xl rounded-tl-sm border border-slate-800 text-[11px] text-slate-100">
                    "Excuse me, how can I catch the express train to Kyoto?"
                  </div>
                </div>

                {/* Speaker 2 (Japanese Translated Instant response) */}
                <div className="flex flex-col gap-1 items-end max-w-[85%] self-end">
                  <div className="flex items-center gap-1">
                    <span className="text-[8px] text-slate-400 font-mono">Japanese Translation</span>
                    <span className="text-[10px]">🇯🇵</span>
                  </div>
                  <div className="bg-gradient-to-r from-neon-purple/40 to-indigo-950/70 p-2.5 rounded-2xl rounded-tr-sm border border-neon-purple/30 text-[11px] text-slate-100 font-medium">
                    "すみません、京都行きの急行列車にはどうすれば乗れますか？"
                    <div className="text-[8px] text-neon-blue font-mono mt-1 flex items-center gap-0.5">
                      <Play className="w-2 h-2 fill-current" /> Auto-playing audio...
                    </div>
                  </div>
                </div>

                {/* Next Speaker typing bubble */}
                <div className="flex items-center gap-1 max-w-[85%] self-start pt-1">
                  <span className="text-[10px]">🇺🇸</span>
                  <div className="flex gap-1 bg-slate-900 border border-slate-800/80 py-2 px-3 rounded-full">
                    <span className="w-1.5 h-1.5 bg-neon-blue rounded-full animate-bounce" />
                    <span className="w-1.5 h-1.5 bg-neon-blue rounded-full animate-bounce [animation-delay:0.2s]" />
                    <span className="w-1.5 h-1.5 bg-neon-blue rounded-full animate-bounce [animation-delay:0.4s]" />
                  </div>
                </div>
              </div>

              {/* Bottom mic active action button inside mockup */}
              <div className="bg-slate-900/80 p-2.5 rounded-2xl border border-slate-800 flex items-center justify-between text-slate-200">
                <div className="flex flex-col">
                  <span className="text-[8px] text-slate-400">English ⇄ Japanese</span>
                  <span className="text-[10px] font-bold text-neon-blue">Tap to talk</span>
                </div>
                <div className="w-9 h-9 rounded-full bg-gradient-to-tr from-neon-blue to-neon-purple flex items-center justify-center neon-glow-blue cursor-pointer">
                  <Mic className="w-4 h-4 text-slate-950 fill-current" />
                </div>
              </div>
            </div>
          )}

          {/* SCREEN CONTENT 2: CAMERA TRANSLATOR */}
          {type === "camera" && (
            <div className="flex-grow flex flex-col justify-between h-full pt-1">
              {/* App Bar */}
              <div className="flex items-center justify-between border-b border-white/[0.04] pb-2">
                <div className="flex items-center gap-1.5">
                  <Camera className="w-3.5 h-3.5 text-neon-pink" />
                  <span className="font-display font-bold text-xs tracking-wide">CAMERA TRANSLATE</span>
                </div>
                <span className="text-[8px] font-mono text-neon-pink bg-neon-pink/10 px-2 py-0.5 rounded border border-neon-pink/20">LIVE AR</span>
              </div>

              {/* Camera Finder mock */}
              <div className="flex-grow relative my-3 bg-slate-900 rounded-2xl border border-slate-800/80 overflow-hidden flex flex-col items-center justify-center">
                {/* Custom camera crosshairs */}
                <div className="absolute top-3 left-3 w-4 h-4 border-t-2 border-l-2 border-neon-blue" />
                <div className="absolute top-3 right-3 w-4 h-4 border-t-2 border-r-2 border-neon-blue" />
                <div className="absolute bottom-3 left-3 w-4 h-4 border-b-2 border-l-2 border-neon-blue" />
                <div className="absolute bottom-3 right-3 w-4 h-4 border-b-2 border-r-2 border-neon-blue" />

                {/* Simulated Street View Sign */}
                <div className="text-center p-3">
                  <div className="text-[10px] uppercase tracking-widest text-slate-500 font-mono mb-2">Original Sign (French)</div>
                  <div className="bg-slate-950/80 py-1.5 px-3 rounded-lg border border-slate-800/60 inline-block">
                    <span className="font-display font-semibold text-slate-200 text-xs">"ENTRÉE INTERDITE"</span>
                  </div>

                  {/* High tech connecting line */}
                  <div className="h-6 w-0.5 bg-gradient-to-b from-neon-blue to-neon-pink mx-auto my-2.5 animate-pulse" />

                  {/* AR translation overlay */}
                  <div className="text-[10px] uppercase tracking-widest text-neon-pink font-mono mb-2">AR Translated Layer</div>
                  <div className="bg-neon-pink/10 py-2.5 px-3 rounded-lg border border-neon-pink/30 inline-block backdrop-blur-sm shadow-[0_0_12px_rgba(255,0,127,0.2)]">
                    <span className="font-display font-semibold text-neon-pink text-xs uppercase tracking-wide">"NO ENTRY ALLOWED"</span>
                  </div>
                </div>

                {/* Scanner bar animation */}
                <div className="absolute w-full h-[2px] bg-gradient-to-r from-transparent via-neon-pink to-transparent top-1/2 left-0 -translate-y-1/2 animate-bounce" />
              </div>

              {/* Camera Actions bar */}
              <div className="flex justify-around items-center bg-slate-950/90 py-2 rounded-xl border border-slate-800">
                <button className="p-1.5 text-slate-400 hover:text-slate-200">⚡</button>
                <button className="w-10 h-10 rounded-full border-2 border-white flex items-center justify-center p-0.5">
                  <div className="w-full h-full rounded-full bg-neon-pink" />
                </button>
                <button className="p-1.5 text-slate-400 hover:text-slate-200">📷</button>
              </div>
            </div>
          )}

          {/* SCREEN CONTENT 3: HISTORY & TRAVEL KIT */}
          {type === "history" && (
            <div className="flex-grow flex flex-col justify-between h-full pt-1">
              {/* App Bar */}
              <div className="flex items-center justify-between border-b border-white/[0.04] pb-2">
                <div className="flex items-center gap-1.5">
                  <History className="w-3.5 h-3.5 text-neon-blue" />
                  <span className="font-display font-bold text-xs tracking-wide">TRAVEL LOGS</span>
                </div>
                <span className="text-[8px] text-slate-400 font-mono">14 SAVED</span>
              </div>

              {/* History list */}
              <div className="flex-grow flex flex-col gap-2 py-3 overflow-y-auto no-scrollbar">
                
                {/* Item 1 */}
                <div className="p-2.5 bg-slate-900 rounded-xl border border-slate-800/80 flex flex-col gap-1.5">
                  <div className="flex items-center justify-between">
                    <span className="text-[8px] font-mono text-slate-400">TODAY in Tokyo</span>
                    <span className="text-[9px] text-emerald-400 flex items-center gap-0.5">
                      <Check className="w-2.5 h-2.5" /> Bookmarked
                    </span>
                  </div>
                  <p className="text-[10px] text-slate-300 italic font-light">"How much to the nearest hotel?"</p>
                  <p className="text-[10px] text-neon-blue font-semibold">"一番近いホテルまでいくらですか？"</p>
                </div>

                {/* Item 2 */}
                <div className="p-2.5 bg-slate-900 rounded-xl border border-slate-800/80 flex flex-col gap-1.5">
                  <div className="flex items-center justify-between">
                    <span className="text-[8px] font-mono text-slate-400">YESTERDAY in Paris</span>
                    <span className="text-[9px] text-neon-purple font-mono">French</span>
                  </div>
                  <p className="text-[10px] text-slate-300 italic font-light">"I would like to purchase a croissant."</p>
                  <p className="text-[10px] text-neon-purple font-semibold">"Je voudrais acheter un croissant."</p>
                </div>

                {/* Item 3 */}
                <div className="p-2.5 bg-slate-900/60 rounded-xl border border-slate-800/40 flex flex-col gap-1.5 opacity-60">
                  <div className="flex items-center justify-between">
                    <span className="text-[8px] font-mono text-slate-500">3 DAYS AGO in Rome</span>
                    <span className="text-[9px] text-slate-500 font-mono">Italian</span>
                  </div>
                  <p className="text-[10px] text-slate-400 italic font-light">"Where is the bathroom?"</p>
                  <p className="text-[10px] text-slate-400 font-semibold">"Dov'è il bagno?"</p>
                </div>

              </div>

              {/* Static Offline Travel Stats card */}
              <div className="bg-gradient-to-tr from-[#02001e] to-indigo-950 p-2.5 rounded-xl border border-neon-purple/20 flex items-center justify-between">
                <div className="flex items-center gap-1.5">
                  <div className="w-6 h-6 rounded-lg bg-neon-purple/20 flex items-center justify-center">
                    <Sparkles className="w-3.5 h-3.5 text-neon-purple" />
                  </div>
                  <div className="flex flex-col">
                    <span className="text-[9px] font-semibold text-slate-200">Traveler Stats</span>
                    <span className="text-[7px] text-slate-400">4 global currencies loaded</span>
                  </div>
                </div>
                <ChevronRight className="w-3.5 h-3.5 text-slate-500" />
              </div>
            </div>
          )}

        </div>

        {/* Apple Dynamic Bottom Screen Indicator */}
        <div className="w-full pb-2 flex justify-center bg-slate-950/80">
          <div className="w-24 h-1 bg-slate-700 rounded-full" />
        </div>
      </div>
    </motion.div>
  );
}
