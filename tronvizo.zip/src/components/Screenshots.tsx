import React, { useState } from "react";
import { motion } from "motion/react";
import PhoneMockup from "./PhoneMockup";
import { Sparkles, ArrowRight, Eye, ShieldCheck, Heart } from "lucide-react";
import { ScreenshotScreen } from "../types";

export default function Screenshots() {
  const [activeScreenId, setActiveScreenId] = useState<string>("chat");

  const screens: ScreenshotScreen[] = [
    {
      id: "chat",
      name: "Dialogue Mode",
      title: "Real-time Vocal Conversation Engine",
      subtitle: "Full-duplex speech recognition connects you with anyone, instantly.",
      type: "chat",
      color: "from-neon-blue to-blue-600",
    },
    {
      id: "camera",
      name: "AR Lens Translate",
      title: "Augmented Vision Translate Layer",
      subtitle: "Drape an AI translation filter over street signs, subways, and food menus.",
      type: "camera",
      color: "from-neon-pink to-rose-600",
    },
    {
      id: "history",
      name: "Travel Logs Mode",
      title: "Saved Travel Kits & Offline History",
      subtitle: "Pin crucial translations in organized logs for instant offline retrieval.",
      type: "history",
      color: "from-neon-purple to-indigo-600",
    },
  ];

  return (
    <section id="screenshots" className="py-24 px-4 md:px-8 bg-slate-950/40 relative">
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_bottom,rgba(189,0,255,0.03),transparent_60%)] pointer-events-none" />

      <div className="max-w-6xl mx-auto">
        {/* Section Header */}
        <div className="text-center mb-16 relative">
          <span className="text-xs font-mono tracking-widest text-transparent bg-clip-text bg-gradient-to-r from-neon-pink to-neon-purple uppercase font-bold py-1.5 px-3 rounded-full border border-neon-pink/20 bg-slate-950/80">
            EXPERIENCE THE INTERFACE
          </span>
          <h2 className="text-3xl md:text-5xl font-display font-black text-white tracking-tight mt-4">
            Futuristic Software Design
          </h2>
          <p className="mt-4 text-base md:text-lg text-slate-400 max-w-2xl mx-auto font-light leading-relaxed">
            Beautiful glassmorphic widgets, ultra-legible typography, and ergonomic controls designed for active globe-trotters.
          </p>
        </div>

        {/* Dynamic Selector Row */}
        <div className="flex justify-center flex-wrap gap-2 md:gap-3 mb-14 bg-slate-900/40 p-2 rounded-2xl max-w-lg mx-auto border border-slate-800/80 backdrop-blur-sm">
          {screens.map((screen) => (
            <button
              key={screen.id}
              onClick={() => setActiveScreenId(screen.id)}
              className={`px-4 py-2 text-xs md:text-sm font-semibold tracking-wide rounded-xl transition-all duration-300 flex items-center gap-1.5 cursor-pointer ${
                activeScreenId === screen.id
                  ? "bg-gradient-to-r from-neon-blue to-neon-purple text-slate-950 font-bold shadow-[0_0_12px_rgba(0,240,255,0.3)]"
                  : "text-slate-400 hover:text-slate-100 hover:bg-slate-800/40"
              }`}
            >
              <span>{screen.name}</span>
            </button>
          ))}
        </div>

        {/* Phone mockups & details grid */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
          {/* Active Information description */}
          <div className="lg:col-span-5 flex flex-col justify-center text-left">
            {screens.map((screen) => {
              if (screen.id !== activeScreenId) return null;
              return (
                <motion.div
                  key={screen.id}
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  exit={{ opacity: 0, x: 20 }}
                  transition={{ duration: 0.4 }}
                  className="space-y-6"
                >
                  <div className={`inline-flex items-center gap-1.5 px-3 py-1 text-xs font-mono tracking-wider font-semibold uppercase rounded-full border bg-slate-900 border-white/10`}>
                    <Sparkles className="w-3.5 h-3.5 text-neon-blue" />
                    <span>Active Interface View</span>
                  </div>

                  <h3 className="text-2xl md:text-4xl font-display font-extrabold text-white leading-tight">
                    {screen.title}
                  </h3>

                  <p className="text-sm md:text-base text-slate-400 font-light leading-relaxed">
                    {screen.subtitle}
                  </p>

                  {/* High Tech Highlights list */}
                  <div className="space-y-3 pt-2">
                    <div className="flex items-start gap-3">
                      <div className="mt-1 w-1.5 h-1.5 rounded-full bg-neon-blue shadow-[0_0_8px_rgba(0,240,255,1)] flex-shrink-0" />
                      <p className="text-xs font-mono uppercase text-slate-300">
                        Zero lag processing: optimized for instant response
                      </p>
                    </div>
                    <div className="flex items-start gap-3">
                      <div className="mt-1 w-1.5 h-1.5 rounded-full bg-neon-purple shadow-[0_0_8px_rgba(189,0,255,1)] flex-shrink-0" />
                      <p className="text-xs font-mono uppercase text-slate-300">
                        OLED-Safe palette: high contrast color mapping
                      </p>
                    </div>
                    <div className="flex items-start gap-3">
                      <div className="mt-1 w-1.5 h-1.5 rounded-full bg-neon-pink shadow-[0_0_8px_rgba(255,0,127,1)] flex-shrink-0" />
                      <p className="text-xs font-mono uppercase text-slate-300">
                        Fluid keyframe waves syncing with sound pitch
                      </p>
                    </div>
                  </div>

                  <button
                    onClick={() => {
                      const playground = document.getElementById("translator-interactive-playground");
                      if (playground) playground.scrollIntoView({ behavior: "smooth" });
                    }}
                    className="inline-flex items-center gap-1.5 text-xs font-bold font-mono text-neon-blue uppercase tracking-wider group hover:text-white transition-colors cursor-pointer"
                  >
                    <span>Test translation live above</span>
                    <ArrowRight className="w-4 h-4 transition-transform duration-300 group-hover:translate-x-1.5" />
                  </button>
                </motion.div>
              );
            })}
          </div>

          {/* Interactive display of all 3 phone mockups */}
          <div className="lg:col-span-7 flex flex-wrap justify-center gap-6 items-center">
            {["chat", "camera", "history"].map((t) => (
              <div 
                key={t}
                onClick={() => setActiveScreenId(t)}
                className={`cursor-pointer transition-all duration-500 hover:scale-102 ${
                  activeScreenId === t 
                    ? "opacity-100 scale-100 z-10" 
                    : "opacity-40 hover:opacity-80 scale-95"
                } hidden md:block`}
              >
                <PhoneMockup type={t as "chat" | "camera" | "history"} active={activeScreenId === t} />
              </div>
            ))}

            {/* Mobile View: single mockup showing selected screen */}
            <div className="block md:hidden">
              <PhoneMockup type={activeScreenId as "chat" | "camera" | "history"} active={true} />
            </div>
          </div>
        </div>

      </div>
    </section>
  );
}
