import React from "react";
import { motion } from "motion/react";
import { 
  Mic, 
  Type, 
  Volume2, 
  Languages, 
  Cpu, 
  Zap, 
  Layout, 
  Moon, 
  Sparkles, 
  ChevronRight, 
  ArrowRight,
  ShieldCheck,
  PlaneTakeoff
} from "lucide-react";
import { Feature } from "../types";

export default function Features() {
  const featuresList: Feature[] = [
    {
      id: "voice",
      title: "Real-time Voice Translation",
      description: "Speak naturally in your native language and hear instant translated feedback out loud in seconds. Designed for seamless interactions.",
      icon: Mic,
      badge: "Flagship",
      gradient: "from-cyan-500/10 to-blue-600/10 border-cyan-500/20 text-neon-blue",
    },
    {
      id: "stt",
      title: "Speech to Text",
      description: "See your spoken words transcribed in real time. Perfect for reading back long responses or writing down vital travel directions.",
      icon: Type,
      gradient: "from-purple-500/10 to-pink-600/10 border-neon-purple/25 text-neon-purple",
    },
    {
      id: "tts",
      title: "Text to Speech",
      description: "Read translation out loud with gorgeous context-aware native local speaker accents. No more struggling with unfamiliar pronunciations.",
      icon: Volume2,
      gradient: "from-pink-500/10 to-red-600/10 border-neon-pink/20 text-neon-pink",
    },
    {
      id: "languages",
      title: "Multiple Languages",
      description: "Unlock immediate access to over 100+ global languages, local dialects, and speech systems. Travel universally without communication limits.",
      icon: Languages,
      badge: "World-wide",
      gradient: "from-emerald-500/10 to-teal-600/10 border-emerald-500/25 text-emerald-400",
    },
    {
      id: "ai",
      title: "AI Powered Context",
      description: "Infused with state-of-the-art context-aware language reasoning. Understands phrases, cultural idioms, slang, and tourist questions accurately.",
      icon: Cpu,
      badge: "Gemini",
      gradient: "from-blue-500/10 to-indigo-600/10 border-blue-500/25 text-neon-blue",
    },
    {
      id: "speed",
      title: "Fast & Accurate",
      description: "Sub-200ms processing threshold drives translation outputs natively. Powered by optimized server-side nodes for low lag.",
      icon: Zap,
      gradient: "from-amber-500/10 to-orange-600/10 border-amber-500/25 text-amber-400",
    },
    {
      id: "ui",
      title: "Simple Traveler UI",
      description: "Featuring a high-contrast minimalist interface. Giant voice triggers designed for quick access on busy train stations or markets.",
      icon: Layout,
      gradient: "from-indigo-500/10 to-purple-600/10 border-indigo-500/25 text-indigo-400",
    },
    {
      id: "dark",
      title: "Optimized Dark Mode",
      description: "OLED-black native interface preserves maximum battery life during long-distance travels. Prevents unwanted eye strain at night.",
      icon: Moon,
      gradient: "from-slate-500/10 to-zinc-600/10 border-slate-700/50 text-slate-400",
    },
  ];

  return (
    <section id="features" className="relative py-24 px-4 md:px-8">
      {/* Visual neon ambient lamps */}
      <div className="absolute right-1/4 top-1/3 w-96 h-96 bg-neon-purple/5 rounded-full blur-3xl pointer-events-none" />
      <div className="absolute left-1/4 bottom-1/3 w-96 h-96 bg-neon-blue/5 rounded-full blur-3xl pointer-events-none" />

      <div className="max-w-6xl mx-auto">
        
        {/* Section Header */}
        <div className="text-center mb-16 relative">
          <span className="text-xs font-mono tracking-widest text-transparent bg-clip-text bg-gradient-to-r from-neon-blue to-neon-purple uppercase font-bold py-1.5 px-3 rounded-full border border-neon-purple/20 bg-slate-950/80">
            ENGINEERED FOR TRAVELERS
          </span>
          <h2 className="text-3xl md:text-5xl font-display font-extrabold text-white tracking-tight mt-4">
            Groundbreaking Features of TRONVIZO
          </h2>
          <p className="mt-4 text-base md:text-lg text-slate-400 max-w-2xl mx-auto font-light leading-relaxed">
            Eliminate cross-border speech barriers. TRONVIZO brings the next generation of voice translation tools directly into your pocket.
          </p>
        </div>

        {/* Bento Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {featuresList.map((feature, idx) => {
            const IconComponent = feature.icon as React.ComponentType<{ className?: string }>;
            return (
              <motion.div
                key={feature.id}
                className={`glass-morphic rounded-2xl p-6 flex flex-col justify-between transition-all duration-300 hover:scale-[1.02] border relative group overflow-hidden ${
                  feature.id === "voice" || feature.id === "ai" 
                    ? "md:col-span-2 hover:shadow-[0_0_24px_rgba(0,240,255,0.15)]" 
                    : "hover:shadow-[0_0_20px_rgba(189,0,255,0.15)]"
                }`}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true, margin: "-100px" }}
                transition={{ duration: 0.5, delay: idx * 0.05 }}
              >
                {/* Background glow hover effect */}
                <div className={`absolute inset-0 bg-gradient-to-br ${feature.gradient} opacity-0 group-hover:opacity-100 transition-opacity duration-500 -z-10`} />

                <div>
                  {/* Badge flag */}
                  {feature.badge && (
                    <span className="absolute top-4 right-4 text-[9px] font-mono uppercase tracking-widest bg-slate-900/90 text-slate-300 py-1 px-2.5 rounded-full border border-slate-800">
                      {feature.badge}
                    </span>
                  )}

                  {/* Icon Frame */}
                  <div className={`w-12 h-12 rounded-xl flex items-center justify-center border bg-slate-950/80 mb-5 relative overflow-hidden group-hover:border-white/30 transition-all ${feature.id === "voice" || feature.id === "ai" ? "border-neon-blue/30" : "border-slate-800"}`}>
                    <IconComponent className="w-6 h-6 group-hover:scale-110 transition-transform duration-300" />
                  </div>

                  {/* Text details */}
                  <h3 className="text-lg font-display font-semibold text-slate-100 group-hover:text-white transition-colors">
                    {feature.title}
                  </h3>
                  
                  <p className="mt-2.5 text-xs md:text-sm text-slate-400 font-light leading-relaxed group-hover:text-slate-300 transition-colors">
                    {feature.description}
                  </p>
                </div>

                <div className="mt-6 flex items-center gap-1.5 text-xs font-mono font-bold uppercase tracking-wider text-slate-500 group-hover:text-neon-blue transition-colors self-start">
                  <span>Explore UI</span>
                  <ArrowRight className="w-3.5 h-3.5 transition-transform duration-300 group-hover:translate-x-1" />
                </div>
              </motion.div>
            );
          })}
        </div>

        {/* Travel Banner Sub-section */}
        <motion.div 
          className="mt-12 p-6 md:p-8 rounded-2xl bg-gradient-to-r from-neon-blue/10 via-[#010015] to-neon-purple/10 border border-slate-800/80 flex flex-col md:flex-row justify-between items-center gap-6"
          initial={{ opacity: 0, scale: 0.98 }}
          whileInView={{ opacity: 1, scale: 1 }}
          viewport={{ once: true }}
        >
          <div className="flex items-center gap-4">
            <div className="w-12 h-12 bg-neon-blue/15 rounded-full flex items-center justify-center text-neon-blue flex-shrink-0">
              <PlaneTakeoff className="w-6 h-6 animate-pulse" />
            </div>
            <div>
              <h4 className="text-base font-semibold text-slate-100">Ready for your upcoming cross-border voyage?</h4>
              <p className="text-xs text-slate-400 font-light mt-0.5">TRONVIZO requires NO network coverage for preset core travel translations offline.</p>
            </div>
          </div>
          <a 
            href="#download-apk-hub"
            className="whitespace-nowrap px-5 py-2.5 rounded-full bg-slate-900 hover:bg-slate-800 text-slate-200 hover:text-white border border-slate-800 hover:border-slate-600 transition-all font-mono text-xs font-bold tracking-wider uppercase flex items-center gap-1.5 cursor-pointer"
          >
            <span>Claim Free APK</span>
            <ChevronRight className="w-4 h-4" />
          </a>
        </motion.div>

      </div>
    </section>
  );
}
