import { LucideIcon } from "lucide-react";

export interface Feature {
  id: string;
  title: string;
  description: string;
  icon: string | LucideIcon;
  badge?: string;
  gradient: string;
}

export interface ScreenshotScreen {
  id: string;
  name: string;
  title: string;
  subtitle: string;
  type: "chat" | "camera" | "history";
  color: string;
}

export interface Language {
  code: string;
  name: string;
  flag: string;
  locale: string; // for speech synthesis
  placeholder: string;
}

export interface TranslationPreset {
  source: string;
  target: string;
  text: string;
  translation: string;
}
